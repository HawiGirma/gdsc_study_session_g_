package com.example.book_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
